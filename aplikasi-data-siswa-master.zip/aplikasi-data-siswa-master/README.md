# Kelompok 01 - Forensic Network Security

Implementasi Web Application Firewall Untuk Mencegah Serangan SQL Injection
Studi Kasus: Aplikasi Data Siswa 📌

Tech💻

- Menggunakan bahasa pemrograman PHP versi 8.
- Menggunakan database management system MySQL versi 8.
- Menggunakan MySQLi Extension untuk berkomunikasi dengan database.
- Menggunakan framework CSS Bootstrap 5 untuk membuat desain tampilan aplikasi.
- Menggunakan Vanilla JavaScript untuk membuat aplikasi web dinamis dan interaktif.

Anggota🙍‍♂️

- Akbar Darmawan - 23552012005 (Lead)
- Albi Mudakar Nasyabi - 21552011235 (Penetration Testing)
- Aldi Ardyansyah - 21552011236 (Developement)
- Aditya Rizki Maulana - 21552011299 (Deployment)
- Alfridus Elman - 21552011304 (System Analys)

Aplikasi Data Siswa: [Documentation-v1](https://github.com/albimdkr/aplikasi-data-siswa/blob/master/Documentation-v1.txt)
<br>
Template Code By: [Pustaka Coding](https://github.com/pustakakoding/aplikasi-crud-php8-mysql8-bootstrap5-vanillajs)
